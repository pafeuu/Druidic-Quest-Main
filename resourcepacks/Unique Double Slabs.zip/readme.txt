Howdy! Thanks for downloading my resource pack!

If you have any suggestions, feedback, or just want to say hi, feel free to contact me through PlanetMinecraft or CurseForge.
Any support is greatly appreciated! n-n

You can find the Terms Of Use for this texture pack on its official CurseForge, Modrinth, and PlanetMinecraft pages.

CurseForge:
https://www.curseforge.com/members/byboxi_/projects

Modrinth:
https://modrinth.com/user/ByBoxi

Planet Minecraft:
https://www.planetminecraft.com/member/byboxi/

Created by ByBoxi